#!/usr/bin/env node
// Sanity-checks public/ after scripts/generate.js has run. Fails the Netlify build loudly
// instead of silently deploying a broken site.
'use strict';
const fs = require('fs');
const path = require('path');
const PUBLIC_DIR = path.resolve(__dirname, '..', 'public');
const errors = [];

function walk(dir) {
  let files = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) files = files.concat(walk(full));
    else files.push(full);
  }
  return files;
}

for (const f of ['index.html', 'el/index.html', '404.html', 'robots.txt', 'sitemap.xml', 'admin/index.html', 'admin/config.yml']) {
  if (!fs.existsSync(path.join(PUBLIC_DIR, f))) errors.push('Missing required file: ' + f);
}

const htmlFiles = walk(PUBLIC_DIR).filter(f => f.endsWith('.html'));
for (const f of htmlFiles) {
  const rel = path.relative(PUBLIC_DIR, f);
  const h = fs.readFileSync(f, 'utf8');
  if (/%%[A-Z_]+%%/.test(h)) errors.push(`Unreplaced %%placeholder%% in ${rel}`);
  const ldMatches = [...h.matchAll(/<script type="application\/ld\+json">\s*([\s\S]*?)\s*<\/script>/g)];
  for (const m of ldMatches) {
    try { JSON.parse(m[1]); } catch (e) { errors.push(`Invalid JSON-LD in ${rel}: ${e.message}`); }
  }
  for (const m of h.matchAll(/(?:src|href)="\/?(images\/[^"?#]+)"/g)) {
    if (!fs.existsSync(path.join(PUBLIC_DIR, m[1]))) errors.push(`${rel}: references missing ${m[1]}`);
  }
}

if (errors.length) {
  console.error('Build failed:\n - ' + errors.join('\n - '));
  process.exit(1);
}
console.log(`Build OK: ${htmlFiles.length} HTML pages validated, publish directory = public`);
