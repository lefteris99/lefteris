// Spec-label and enum translation tables (Greek), ported from the site's original i18n pass.
// Free-text fields (features/description/note) use the car's *_el override when the dealer
// provides one in the CMS; otherwise the English text is shown on the Greek page with no
// invented translation, since fabricating Greek prose for an unreviewed car is worse than
// falling back to English for that one field.
const FUEL = { Petrol: "Βενζίνη", Diesel: "Diesel", Hybrid: "Υβριδικό", Electric: "Ηλεκτρικό" };
const GEAR = { Automatic: "Αυτόματο", Manual: "Χειροκίνητο" };
const COLOR = { Black: "Μαύρο", White: "Λευκό", Silver: "Ασημί", Blue: "Μπλε", Red: "Κόκκινο", Grey: "Γκρι", Gray: "Γκρι" };
const COND = {
  "Excellent condition": "Άριστη κατάσταση", "Very good condition": "Πολύ καλή κατάσταση",
  "Like new condition": "Σαν καινούργιο", "Good condition": "Καλή κατάσταση",
};
function translateAvailability(s) {
  if (!s) return "Διαθέσιμο";
  if (/^in stock$/i.test(s)) return "Διαθέσιμο";
  if (/^arriving/i.test(s)) return s.replace(/^Arriving/i, "Φτάνει");
  return s; // unrecognised phrasing: show as the dealer wrote it rather than guess
}
function translateDrive(d) {
  if (!d) return d;
  return d.replace(/Front-wheel drive/i, "Κίνηση στους μπροστινούς τροχούς")
    .replace(/All-wheel drive/i, "Τετρακίνηση")
    .replace(/Rear-wheel drive/i, "Κίνηση στους πίσω τροχούς");
}
function translateDoors(d) { return d ? d.replace(/door/i, "πόρτες") : d; }
function gr(n) { return Number(n).toLocaleString("en-US").replace(/,/g, "."); }

module.exports = { FUEL, GEAR, COLOR, COND, translateAvailability, translateDrive, translateDoors, gr };
