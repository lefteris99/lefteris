#!/usr/bin/env node
// Regenerates the car-data-driven parts of the site from /content/cars/*.json:
//   - public/index.html and public/el/index.html: the car grid + the ItemList in JSON-LD
//   - public/cars/<slug>/index.html and public/el/cars/<slug>/index.html: one page per car
//   - public/sitemap.xml
//   - public/llms.txt (car list section)
// Everything else in those files (hero, reviews, FAQ, footer, CSS, nav) is untouched.
'use strict';
const fs = require('fs');
const path = require('path');
const { FUEL, GEAR, COND, translateAvailability, translateDrive, translateDoors, gr } = require('./translate');

const ROOT = path.resolve(__dirname, '..');
const CONTENT_DIR = path.join(ROOT, 'content', 'cars');
const PUBLIC_DIR = path.join(ROOT, 'public');
const SITE = 'https://www.xatzismotors.com/';
const WA_BASE = 'https://wa.me/35799060388';
const DEALER_ID = SITE + '#dealer';

function esc(s) {
  return String(s).replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
}
function money(n) { return '\u20ac' + Number(n).toLocaleString('en-US'); }
function waLink(text) { return WA_BASE + '?text=' + encodeURIComponent(text); }

function loadCars() {
  const files = fs.readdirSync(CONTENT_DIR).filter(f => f.endsWith('.json')).sort();
  return files.map(f => {
    const c = JSON.parse(fs.readFileSync(path.join(CONTENT_DIR, f), 'utf8'));
    if (!c.slug) c.slug = f.replace(/\.json$/, '');
    if (c.status === undefined) c.status = 'available';
    if (c.featured === undefined) c.featured = false;
    return c;
  });
}

function liveCars(cars) {
  // Draft and Sold cars are kept in content/ for the record but are not published on the site.
  return cars.filter(c => c.status === 'available');
}

// ---------------- English & Greek field views ----------------
function enView(c) {
  return {
    name: c.name, btype: c.btype, fuel: c.fuel, gear: c.gear, color: c.color,
    doors: c.doors, drive: c.drive, condition: c.condition,
    availability: c.availability, features: c.features || [], desc: c.desc || [], note: c.note || '',
  };
}
function elView(c) {
  const fallbackNote = c.note_el !== undefined ? c.note_el : c.note || '';
  return {
    name: c.name_el || c.name,
    btype: c.btype, // body style words (SUV, Hatchback...) are kept as-is, same convention as the live site
    fuel: FUEL[c.fuel] || c.fuel,
    gear: GEAR[c.gear] || c.gear,
    color: c.color, // colour words aren't in the dictionary set yet; shown as entered
    doors: translateDoors(c.doors),
    drive: translateDrive(c.drive),
    condition: COND[c.condition] || c.condition,
    availability: translateAvailability(c.availability),
    features: (c.features_el && c.features_el.length) ? c.features_el : (c.features || []),
    desc: (c.desc_el && c.desc_el.length) ? c.desc_el : (c.desc || []),
    note: fallbackNote,
  };
}

function hlFromDesc(desc, mot, lang) {
  const base = desc.slice(0, 3).join(', ');
  if (!mot) return base + '.';
  return base + (lang === 'el' ? ('. MOT \u03ad\u03c9\u03c2 ' + mot + '.') : ('. MOT until ' + mot + '.'));
}

// ---------------- car JSON-LD ----------------
function carJsonLd(c, view, carUrl, lang) {
  const avail = c.status === 'sold' ? 'https://schema.org/SoldOut'
    : /arriving|\u03c6\u03c4\u03ac\u03bd\u03b5\u03b9/i.test(view.availability) ? 'https://schema.org/PreOrder'
    : 'https://schema.org/InStock';
  const graph = [
    { '@type': 'BreadcrumbList', itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'Xatzis Motors', item: lang === 'el' ? SITE + 'el/' : SITE },
      { '@type': 'ListItem', position: 2, name: lang === 'el' ? '\u0391\u03c5\u03c4\u03bf\u03ba\u03af\u03bd\u03b7\u03c4\u03b1 \u03c0\u03c1\u03bf\u03c2 \u03c0\u03ce\u03bb\u03b7\u03c3\u03b7' : 'Cars for sale', item: (lang === 'el' ? SITE + 'el/' : SITE) + '#cars' },
      { '@type': 'ListItem', position: 3, name: view.name, item: carUrl },
    ] },
    { '@type': 'Car', '@id': carUrl, url: carUrl, name: view.name,
      brand: { '@type': 'Brand', name: c.brand }, model: c.model,
      vehicleModelDate: String(c.year), bodyType: view.btype, color: view.color, fuelType: view.fuel,
      vehicleTransmission: view.gear, vehicleSeatingCapacity: c.seats, driveWheelConfiguration: view.drive,
      mileageFromOdometer: { '@type': 'QuantitativeValue', value: c.km, unitCode: 'KMT' },
      image: c.gallery, description: view.desc.join(' '), inLanguage: lang,
      vehicleEngine: { '@type': 'EngineSpecification', fuelType: view.fuel },
      offers: { '@type': 'Offer', price: String(c.price), priceCurrency: 'EUR', url: carUrl,
        itemCondition: 'https://schema.org/UsedCondition', availability: avail, seller: { '@id': DEALER_ID } } },
  ];
  return JSON.stringify({ '@context': 'https://schema.org', '@graph': graph }, null, 2);
}

// ---------------- render one car page ----------------
function specRows(c, view, lang) {
  const L = lang === 'el'
    ? { price: '\u03a4\u03b9\u03bc\u03ae', year: '\u0388\u03c4\u03bf\u03c2', km: '\u03a7\u03b9\u03bb\u03b9\u03cc\u03bc\u03b5\u03c4\u03c1\u03b1', fuel: '\u039a\u03b1\u03cd\u03c3\u03b9\u03bc\u03bf', gear: '\u039a\u03b9\u03b2\u03ce\u03c4\u03b9\u03bf', drive: '\u039a\u03af\u03bd\u03b7\u03c3\u03b7', btype: '\u03a4\u03cd\u03c0\u03bf\u03c2 \u03b1\u03bc\u03b1\u03be\u03ce\u03bc\u03b1\u03c4\u03bf\u03c2', doors: '\u03a0\u03cc\u03c1\u03c4\u03b5\u03c2', seats: '\u0398\u03ad\u03c3\u03b5\u03b9\u03c2', color: '\u03a7\u03c1\u03ce\u03bc\u03b1', mot: 'MOT \u03ad\u03c9\u03c2', condition: '\u039a\u03b1\u03c4\u03ac\u03c3\u03c4\u03b1\u03c3\u03b7', availability: '\u0394\u03b9\u03b1\u03b8\u03b5\u03c3\u03b9\u03bc\u03cc\u03c4\u03b7\u03c4\u03b1' }
    : { price: 'Price', year: 'Year', km: 'Mileage', fuel: 'Fuel', gear: 'Gearbox', drive: 'Drive', btype: 'Body type', doors: 'Doors', seats: 'Seats', color: 'Colour', mot: 'MOT until', condition: 'Condition', availability: 'Availability' };
  const kmTxt = lang === 'el' ? gr(c.km) + ' \u03c7\u03bb\u03bc' : c.km.toLocaleString() + ' km';
  const rows = [
    [L.price, money(c.price)], [L.year, String(c.year)], [L.km, kmTxt], [L.fuel, view.fuel], [L.gear, view.gear],
    [L.drive, view.drive], [L.btype, view.btype], [L.doors, view.doors], [L.seats, String(c.seats)], [L.color, view.color],
  ];
  if (c.mot) rows.push([L.mot, c.mot]);
  rows.push([L.condition, view.condition], [L.availability, view.availability]);
  return rows.map(([k, v]) => `          <tr><th scope="row">${esc(k)}</th><td>${esc(v)}</td></tr>`).join('\n');
}

function renderCarPage(c, lang, template) {
  const view = lang === 'el' ? elView(c) : enView(c);
  const slugPath = lang === 'el' ? `el/cars/${c.slug}/` : `cars/${c.slug}/`;
  const otherPath = lang === 'el' ? `cars/${c.slug}/` : `el/cars/${c.slug}/`;
  const carUrl = SITE + slugPath;
  const otherUrl = SITE + otherPath;
  const price = lang === 'el' ? gr(c.price) : c.price.toLocaleString();
  const title = `${view.name} \u2013 \u20ac${price} | Xatzis Motors, ${lang === 'el' ? '\u039b\u03ac\u03c1\u03bd\u03b1\u03ba\u03b1' : 'Larnaca'}`;
  let metaDesc = `${view.name}, ${lang === 'el' ? gr(c.km) + ' \u03c7\u03bb\u03bc' : c.km.toLocaleString() + ' km'}, ${view.fuel}, ${view.gear}. \u20ac${price} ${lang === 'el' ? '\u03c3\u03c4\u03bf' : 'at'} Xatzis Motors, ${lang === 'el' ? '\u039b\u03ac\u03c1\u03bd\u03b1\u03ba\u03b1' : 'Larnaca'}. ${view.desc.slice(0, 3).join(', ')}.`;
  if (metaDesc.length > 300) metaDesc = metaDesc.slice(0, 297) + '...';

  const thumbs = c.gallery.map((img, i) => {
    const label = lang === 'el' ? `\u03a6\u03c9\u03c4\u03bf\u03b3\u03c1\u03b1\u03c6\u03af\u03b1 ${i + 1} \u2013 ${esc(view.name)}` : `Photo ${i + 1} of ${esc(view.name)}`;
    return `          <button type="button" data-full="${img}" class="${i === 0 ? 'active' : ''}" aria-label="${label}"><img src="${img}" alt="" width="150" height="150" loading="lazy" referrerpolicy="no-referrer"></button>`;
  }).join('\n');

  const chips = view.features.map(f => `          <li>${esc(f)}</li>`).join('\n');
  const bullets = view.desc.map(d => `            <li>${esc(d)}</li>`).join('\n');
  let noteBlock = '';
  if (view.note) noteBlock = `        <p class="note">${esc(view.note)}</p>`;

  const msg = lang === 'el'
    ? `\u0393\u03b5\u03b9\u03b1 \u03c3\u03b1\u03c2, \u03b5\u03bd\u03b4\u03b9\u03b1\u03c6\u03ad\u03c1\u03bf\u03bc\u03b1\u03b9 \u03b3\u03b9\u03b1 \u03c4\u03bf ${view.name} (\u20ac${price}).`
    : `Hello, I'm interested in the ${view.name} (\u20ac${price}).`;

  let out = template;
  const map = {
    '%%TITLE%%': title, '%%META_DESC%%': esc(metaDesc), '%%CANONICAL%%': carUrl,
    '%%OG_TITLE%%': esc(`${view.name} \u2013 \u20ac${price}`), '%%MAIN_IMG%%': c.gallery[0], '%%PRICE%%': String(c.price),
    '%%CAR_SHORT%%': esc(view.name), '%%NAME%%': esc(view.name), '%%PRICE_FMT%%': price,
    '%%NOTE_BLOCK%%': noteBlock, '%%WA_LINK%%': esc(waLink(msg)), '%%THUMBS%%': thumbs,
    '%%SPEC_ROWS%%': specRows(c, view, lang), '%%FEATURE_CHIPS%%': chips, '%%DESC_BULLETS%%': bullets,
    '%%JSONLD%%': carJsonLd(c, view, carUrl, lang), '%%LANG%%': lang,
    '%%LOCALE%%': lang === 'el' ? 'el_GR' : 'en_GB', '%%LOCALE_ALT%%': lang === 'el' ? 'en_GB' : 'el_GR',
    '%%OTHER_URL%%': otherUrl, '%%OTHER_CODE%%': lang === 'el' ? 'en' : 'el',
    '%%OTHER_LABEL%%': lang === 'el' ? 'English' : '\u0395\u03bb\u03bb\u03b7\u03bd\u03b9\u03ba\u03ac',
    '%%OTHER_SHORT%%': lang === 'el' ? 'EN' : '\u0395\u039b', '%%XDEFAULT_URL%%': SITE + `cars/${c.slug}/`,
  };
  for (const [k, v] of Object.entries(map)) out = out.split(k).join(v);
  if (/%%[A-Z_]+%%/.test(out)) {
    const left = out.match(/%%[A-Z_]+%%/g);
    throw new Error(`Unreplaced placeholder(s) in ${c.slug} (${lang}): ${left.join(', ')}`);
  }
  return out;
}

// ---------------- home page: car grid + JSON-LD ItemList ----------------
function renderCard(c, lang) {
  const view = lang === 'el' ? elView(c) : enView(c);
  const page = lang === 'el' ? `cars/${c.slug}/` : `cars/${c.slug}/`; // home page links are relative to its own folder
  const bodyTag = c.btype === 'SUV' ? 'suv' : c.btype === 'Coupe' ? 'suv' : c.btype === 'Van' ? 'van' : c.btype === 'Sedan' ? 'sedan' : 'hatch';
  const price = lang === 'el' ? gr(c.price) : c.price.toLocaleString();
  const msg = lang === 'el'
    ? `\u0393\u03b5\u03b9\u03b1 \u03c3\u03b1\u03c2, \u03b5\u03bd\u03b4\u03b9\u03b1\u03c6\u03ad\u03c1\u03bf\u03bc\u03b1\u03b9 \u03b3\u03b9\u03b1 \u03c4\u03bf ${view.name} (\u20ac${price}).`
    : `Hello, I'm interested in the ${view.name} (\u20ac${price}).`;
  const askLabel = lang === 'el' ? '\u03a1\u03c9\u03c4\u03ae\u03c3\u03c4\u03b5 \u03b3\u03b9\u03b1 \u03b1\u03c5\u03c4\u03cc \u03c4\u03bf \u03b1\u03c5\u03c4\u03bf\u03ba\u03af\u03bd\u03b7\u03c4\u03bf' : 'Ask about this car';
  const moreLabel = lang === 'el' ? '\u0394\u03b5\u03af\u03c4\u03b5 \u03c6\u03c9\u03c4\u03bf\u03b3\u03c1\u03b1\u03c6\u03af\u03b5\u03c2 \u03ba\u03b1\u03b9 \u03cc\u03bb\u03b1 \u03c4\u03b1 \u03c3\u03c4\u03bf\u03b9\u03c7\u03b5\u03af\u03b1' : 'See photos and full details';
  const kmTxt = lang === 'el' ? gr(c.km) + ' \u03c7\u03bb\u03bc' : c.km.toLocaleString() + ' km';
  const alt = `${view.color} ${view.name} ${lang === 'el' ? '\u03c0\u03c1\u03bf\u03c2 \u03c0\u03ce\u03bb\u03b7\u03c3\u03b7 \u03c3\u03c4\u03bf Xatzis Motors, \u039b\u03ac\u03c1\u03bd\u03b1\u03ba\u03b1' : 'for sale at Xatzis Motors in Larnaca'}`;
  return `        <li class="car" data-tags="${bodyTag}${['Hybrid', 'Electric'].includes(c.fuel) ? ' hybrid' : ''}">
          <a href="${page}" class="car-photo-link" aria-hidden="true" tabindex="-1">
          <img src="${c.gallery[0]}" data-body="${bodyTag}" data-color="${c.hex || '#A9B2BC'}" width="870" height="600" loading="lazy" referrerpolicy="no-referrer" alt="${esc(alt)}">
          </a>
          <div class="car-body">
            <h3><a href="${page}">${esc(view.name)}</a></h3>
            <p class="price">${money(c.price)}</p>
            <ul class="specs"><li><strong>${kmTxt}</strong></li><li><strong>${view.fuel}</strong></li><li>${view.gear}</li><li>${c.year}</li></ul>
            <p class="hl">${esc(hlFromDesc(view.desc, c.mot, lang))}</p>
            <div class="car-actions">
              <a class="btn btn-line" href="${esc(waLink(msg))}">${askLabel}</a>
              <a class="more" href="${page}">${moreLabel}</a>
            </div>
          </div>
        </li>`;
}

function patchHomePage(filePath, lang, cars) {
  let h = fs.readFileSync(filePath, 'utf8');

  // 1. car grid
  const gridRe = /(<ul class="grid" id="grid">\n<!-- CMS:CARS_START -->\n)([\s\S]*?)(\n<!-- CMS:CARS_END -->\n      <\/ul>)/;
  const cardsHtml = cars.map(c => renderCard(c, lang)).join('\n');
  if (!gridRe.test(h)) throw new Error('car grid markers not found in ' + filePath);
  h = h.replace(gridRe, (m, a, _b, c) => a + cardsHtml + c);

  // 2. "Showing N cars" / "N cars available now" counts
  h = h.replace(/Showing \d+ cars?/, `Showing ${cars.length} car${cars.length === 1 ? '' : 's'}`);
  h = h.replace(/\u0395\u03bc\u03c6\u03ac\u03bd\u03b9\u03c3\u03b7 \d+ \u03b1\u03c5\u03c4\u03bf\u03ba\u03b9\u03bd\u03ae\u03c4\u03c9\u03bd/, `\u0395\u03bc\u03c6\u03ac\u03bd\u03b9\u03c3\u03b7 ${cars.length} \u03b1\u03c5\u03c4\u03bf\u03ba\u03b9\u03bd\u03ae\u03c4\u03c9\u03bd`);
  h = h.replace(/\d+ cars available now/, `${cars.length} cars available now`);
  h = h.replace(/\d+ \u03b1\u03c5\u03c4\u03bf\u03ba\u03af\u03bd\u03b7\u03c4\u03b1 \u03b4\u03b9\u03b1\u03b8\u03ad\u03c3\u03b9\u03bc\u03b1 \u03c4\u03ce\u03c1\u03b1/, `${cars.length} \u03b1\u03c5\u03c4\u03bf\u03ba\u03af\u03bd\u03b7\u03c4\u03b1 \u03b4\u03b9\u03b1\u03b8\u03ad\u03c3\u03b9\u03bc\u03b1 \u03c4\u03ce\u03c1\u03b1`);

  // 3. JSON-LD ItemList (parse -> replace itemListElement -> re-stringify; nothing else in @graph touched)
  const ldRe = /(<script type="application\/ld\+json">\n)([\s\S]*?)(\n<\/script>)/;
  const ldMatch = h.match(ldRe);
  if (!ldMatch) throw new Error('JSON-LD block not found in ' + filePath);
  const ld = JSON.parse(ldMatch[2]);
  const itemsNode = ld['@graph'].find(g => g['@type'] === 'ItemList');
  if (!itemsNode) throw new Error('ItemList not found in JSON-LD of ' + filePath);
  itemsNode.itemListElement = cars.map((c, i) => {
    const view = lang === 'el' ? elView(c) : enView(c);
    const carUrl = SITE + (lang === 'el' ? 'el/' : '') + `cars/${c.slug}/`;
    const avail = c.status === 'sold' ? 'https://schema.org/SoldOut'
      : /arriving|\u03c6\u03c4\u03ac\u03bd\u03b5\u03b9/i.test(view.availability) ? 'https://schema.org/PreOrder' : 'https://schema.org/InStock';
    return {
      '@type': 'ListItem', position: i + 1, item: {
        '@type': 'Car', '@id': carUrl, url: carUrl, name: view.name,
        brand: { '@type': 'Brand', name: c.brand }, model: c.model, vehicleModelDate: String(c.year),
        bodyType: view.btype, color: view.color, fuelType: view.fuel, vehicleTransmission: view.gear,
        numberOfDoors: '4-5', vehicleSeatingCapacity: c.seats, driveWheelConfiguration: view.drive,
        mileageFromOdometer: { '@type': 'QuantitativeValue', value: c.km, unitCode: 'KMT' },
        image: c.gallery,
        offers: { '@type': 'Offer', price: String(c.price), priceCurrency: 'EUR', url: carUrl,
          itemCondition: 'https://schema.org/UsedCondition', availability: avail, seller: { '@id': DEALER_ID } },
      },
    };
  });
  h = h.replace(ldRe, (m, a, _b, c) => a + JSON.stringify(ld, null, 2) + c);

  fs.writeFileSync(filePath, h, 'utf8');
}

// ---------------- sitemap + llms.txt ----------------
function writeSitemap(cars) {
  const today = new Date().toISOString().slice(0, 10);
  const urlBlock = (u, alts, pri) => {
    const links = alts.map(([l, a]) => `    <xhtml:link rel="alternate" hreflang="${l}" href="${a}"/>`).join('\n');
    return `  <url>\n    <loc>${u}</loc>\n    <lastmod>${today}</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>${pri}</priority>\n${links}\n  </url>`;
  };
  const pairs = [[SITE, SITE + 'el/', '1.0']].concat(cars.map(c => [SITE + `cars/${c.slug}/`, SITE + `el/cars/${c.slug}/`, '0.8']));
  const blocks = [];
  for (const [en, el] of pairs) {
    const alts = [['en', en], ['el', el], ['x-default', en]];
    blocks.push(urlBlock(en, alts, pairs[0][0] === en ? '1.0' : '0.8'));
    blocks.push(urlBlock(el, alts, pairs[0][0] === en ? '1.0' : '0.8'));
  }
  const xml = '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">\n' + blocks.join('\n') + '\n</urlset>\n';
  fs.writeFileSync(path.join(PUBLIC_DIR, 'sitemap.xml'), xml, 'utf8');
}

function updateLlms(cars) {
  const p = path.join(PUBLIC_DIR, 'llms.txt');
  let txt = fs.existsSync(p) ? fs.readFileSync(p, 'utf8') : '';
  const startMarker = '## Used cars for sale';
  const endMarker = '\n## Car rental';
  const lines = [`${startMarker} (as of ${new Date().toISOString().slice(0, 10)}, prices in EUR)`];
  for (const c of cars) {
    lines.push(`- ${c.name}: ${money(c.price)}, ${c.km.toLocaleString()} km, ${c.fuel}, ${c.gear} \u2014 full details: ${SITE}cars/${c.slug}/`);
  }
  const block = lines.join('\n');
  const si = txt.indexOf(startMarker);
  const ei = txt.indexOf(endMarker);
  if (si > -1 && ei > -1 && ei > si) {
    txt = txt.slice(0, si) + block + txt.slice(ei);
  } else {
    txt += (txt.endsWith('\n') ? '' : '\n') + '\n' + block + '\n';
  }
  fs.writeFileSync(p, txt, 'utf8');
}

// ---------------- main ----------------
function main() {
  const all = loadCars();
  const cars = liveCars(all);
  console.log(`Loaded ${all.length} car(s) from content/, ${cars.length} are published (status=available).`);

  const tplEn = fs.readFileSync(path.join(ROOT, 'scripts', 'templates', 'car_en.html'), 'utf8');
  const tplEl = fs.readFileSync(path.join(ROOT, 'scripts', 'templates', 'car_el.html'), 'utf8');

  // wipe and rewrite public/cars and public/el/cars from scratch so removed/renamed cars don't leave stale pages
  for (const dir of [path.join(PUBLIC_DIR, 'cars'), path.join(PUBLIC_DIR, 'el', 'cars')]) {
    fs.rmSync(dir, { recursive: true, force: true });
    fs.mkdirSync(dir, { recursive: true });
  }
  for (const c of cars) {
    const enDir = path.join(PUBLIC_DIR, 'cars', c.slug);
    const elDir = path.join(PUBLIC_DIR, 'el', 'cars', c.slug);
    fs.mkdirSync(enDir, { recursive: true });
    fs.mkdirSync(elDir, { recursive: true });
    fs.writeFileSync(path.join(enDir, 'index.html'), renderCarPage(c, 'en', tplEn), 'utf8');
    fs.writeFileSync(path.join(elDir, 'index.html'), renderCarPage(c, 'el', tplEl), 'utf8');
  }
  console.log(`Wrote ${cars.length} car page(s) in English and Greek.`);

  patchHomePage(path.join(PUBLIC_DIR, 'index.html'), 'en', cars);
  patchHomePage(path.join(PUBLIC_DIR, 'el', 'index.html'), 'el', cars);
  console.log('Updated home page car grids (EN + EL).');

  writeSitemap(cars);
  updateLlms(cars);
  console.log('Updated sitemap.xml and llms.txt.');
  console.log('Done.');
}

main();
