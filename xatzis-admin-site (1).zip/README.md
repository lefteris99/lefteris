# Xatzis Motors — site + admin

Your car listings now live in `content/cars/*.json` — one file per car. A build
script (`scripts/generate.js`) turns those into the actual web pages (home page
car grid, each car's own page, sitemap) every time the site builds. You manage
the cars through a private admin page at **/admin** — you never touch the
generated HTML yourself.

## One-time setup (about 15 minutes)

This replaces the old "drag a zip into Netlify" workflow with a proper
Git-connected site, which is required for the admin panel to publish changes
automatically.

### 1. Push this folder to GitHub
If you don't already have a GitHub account, make one (free) at github.com.
Create a new **private** repository, then push this folder to it. If you're
not comfortable with git commands, GitHub Desktop (desktop.github.com) does
this with drag-and-drop.

### 2. Connect the repo to your existing Netlify site
In Netlify: your site → **Site configuration → Build & deploy → Continuous
deployment → Link repository**. Pick the GitHub repo you just pushed. Netlify
will read `netlify.toml` automatically (build command and publish folder are
already set). From now on, every change pushed to the repo — including
changes made through the admin panel — rebuilds and republishes the site on
its own.

### 3. Turn on Netlify Identity (this is your login system)
Site → **Identity** tab → **Enable Identity**.
Then **Identity → Registration → set to "Invite only"** — this is the step
that makes sure nobody but you can ever create an account, regardless of
whether they find the `/admin` address.

### 4. Turn on Git Gateway
Still in the Identity tab → **Services → Git Gateway → Enable Git Gateway**.
This lets the admin panel save changes to GitHub on your behalf, without ever
handling a GitHub password itself.

### 5. Invite yourself
Identity tab → **Invite users** → enter your email address. You'll get an
email with a link to set a password. That's your login for `/admin` from now
on — and the only one that will ever exist unless you invite someone else.

### 6. Log in
Go to `https://www.xatzismotors.com/admin`, log in with the password you just
set. You'll see your 13 cars, ready to edit.

## Using it day to day

- **Add a car**: Cars → New Car. Fill it in, upload photos (dragged in, not
  pasted links — these are now hosted on your own site, not borrowed from
  anywhere else), set Status to "Available", hit Publish.
- **Edit a car**: open it from the list, change what you need, Publish.
- **Mark something sold**: open it, change Status to "Sold", Publish. It
  disappears from the live site immediately but the record stays here.
- **Hide a car while you're still working on it**: Status → "Draft".
- **Remove a car for good**: delete it from the list.
- **How fast is "live"?**: a change takes about 1–2 minutes to go live after
  you hit Publish — Netlify has to rebuild the site, same as any change to
  any Netlify site. That's normal and not a bug.

## What's where

- `content/cars/*.json` — the actual car data (what the admin panel edits)
- `public/` — the site Netlify publishes. Don't hand-edit files under
  `public/cars/` or `public/el/` — they're regenerated from `content/` on
  every build and any manual edit there will be overwritten.
- `public/index.html`, `public/el/index.html` — the static parts of the home
  page (hero text, reviews, FAQ, footer) live here directly; only the car
  grid itself is regenerated.
- `scripts/generate.js` — the generator. `scripts/translate.js` — the Greek
  word lists it uses for spec labels (fuel types, gearbox, etc).
- `scripts/validate.js` — runs after every build and fails loudly instead of
  quietly publishing a broken page.

## Known limits, stated plainly

- **"Featured" toggle** is captured in the data but not yet wired into any
  special homepage section — it's there for later.
- **Greek free text**: spec labels (fuel, gearbox, condition, etc.) translate
  automatically. Features, description bullets and notes only appear in Greek
  if you fill in the optional Greek fields for that car — otherwise the
  Greek page shows the English text for just that part, rather than guessing
  a translation.
- **Existing car photos** are still linked from Bazaraki, not hosted here —
  that was true before this change too. New photos you upload through the
  admin panel *are* hosted on your own site from now on.
